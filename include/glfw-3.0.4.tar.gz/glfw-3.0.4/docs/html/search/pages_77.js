var searchData=
[
  ['window_20handling_20guide',['Window handling guide',['../window.html',1,'']]]
];
